
#include "list.h"

bool listIsOrdered(List l) {
	// TODO
	return false;
}

